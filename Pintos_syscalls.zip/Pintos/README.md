This is a variant of the Pintos Operating System for use as part of UFCFWK-15-2 Operating Systems module. 2019/20
